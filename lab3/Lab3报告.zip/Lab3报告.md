**分工：**

苏奕扬：练习1代码的编写和报告的书写

姚鑫秋：challenge1报告，challenge3代码的编写和报告的书写

侯懿轩：challenge2报告，challenge3代码的编写和debug

### 练习1：完善中断处理&#x20;

#### 实现过程

```java
case IRQ_S_TIMER:
             /* LAB3 EXERCISE1   YOUR CODE :2311330  */
            /*(1)设置下次时钟中断- clock_set_next_event()
             *(2)计数器（ticks）加一
             *(3)当计数器加到100的时候，我们会输出一个`100ticks`表示我们触发了100次时钟中断，同时打印次数（num）加一
            * (4)判断打印次数，当打印次数为10时，调用<sbi.h>中的关机函数关机
            */
            clock_set_next_event();
            ticks++;
            if (ticks % TICK_NUM == 0) {
                print_ticks();
                num++;
            }
            if (num == 10) {
                sbi_shutdown();
            }
            break;
```

首先调用clock\_set\_next\_event函数，设置下次的中断时间，为当前时间加上100000

```c++
static uint64_t timebase = 100000;
//对于QEMU, timer增加1，过去了10^-7 s， 也就是100ns
void clock_set_next_event(void) { sbi_set_timer(get_cycles() + timebase); }
```

接着ticks自增1，如果ticks为TICK\_NUM(100)，调用print\_ticks打印ticks，将ticks置0，num自增1。如果num增加到10，调用sbi\_shutdown关机。

#### 定时器中断处理流程：

当发生时钟中断时，会跳转到寄存器stvec保存的地址执行指令，即\_\_alltraps的位置继续执行。

```c++
__alltraps:
    SAVE_ALL

    move  a0, sp
    jal trap
    # sp should be the same as before "jal trap"
```

接着保存所有的寄存器，然后执行mov a0, sp将sp保存到a0中，之后跳转到trap函数继续执行。

```c++
void trap(struct trapframe *tf) {
    // dispatch based on what type of trap occurred
    trap_dispatch(tf);
}
```

然后调用trap\_dispatch函数，判断异常是中断，跳转到处理函数interrupt\_handler处继续执行。

```c++
void interrupt_handler(struct trapframe *tf) {
    intptr_t cause = (tf->cause << 1) >> 1;
    switch (cause) {
        case IRQ_U_SOFT:
            cprintf("User software interrupt\n");
            break;
        case IRQ_S_SOFT:
            cprintf("Supervisor software interrupt\n");
            break;
        case IRQ_H_SOFT:
            cprintf("Hypervisor software interrupt\n");
            break;
        case IRQ_M_SOFT:
            cprintf("Machine software interrupt\n");
            break;
        case IRQ_U_TIMER:
            cprintf("User Timer interrupt\n");
            break;
        case IRQ_S_TIMER:
            // "All bits besides SSIP and USIP in the sip register are
            // read-only." -- privileged spec1.9.1, 4.1.4, p59
            // In fact, Call sbi_set_timer will clear STIP, or you can clear it
            // directly.
            // cprintf("Supervisor timer interrupt\n");
             /* LAB3 EXERCISE1   YOUR CODE :  */
            /*(1)设置下次时钟中断- clock_set_next_event()
             *(2)计数器（ticks）加一
             *(3)当计数器加到100的时候，我们会输出一个`100ticks`表示我们触发了100次时钟中断，同时打印次数（num）加一
            * (4)判断打印次数，当打印次数为10时，调用<sbi.h>中的关机函数关机
            */
            clock_set_next_event();
            ticks++;
            if (ticks % TICK_NUM == 0) {
                print_ticks();
                num++;
            }
            if (num == 10) {
                sbi_shutdown();
            }
            break;
        case IRQ_H_TIMER:
            cprintf("Hypervisor software interrupt\n");
            break;
        case IRQ_M_TIMER:
            cprintf("Machine software interrupt\n");
            break;
        case IRQ_U_EXT:
            cprintf("User software interrupt\n");
            break;
        case IRQ_S_EXT:
            cprintf("Supervisor external interrupt\n");
            break;
        case IRQ_H_EXT:
            cprintf("Hypervisor software interrupt\n");
            break;
        case IRQ_M_EXT:
            cprintf("Machine software interrupt\n");
            break;
        default:
            print_trapframe(tf);
            break;
    }
}
```

最后根据cause的值，跳转到IRQ\_S\_TIMER处继续执行。

**中断返回**

当中断处理完毕后，`trap()` 函数执行完毕，C 语言层自然会 `ret` 返回到调用它的汇编入口——也就是 `__alltraps` 对应的返回部分。

```c++
.globl __trapret
__trapret:
    RESTORE_ALL
    # return from supervisor call
    sret
```

RESTORE\_ALL逐一恢复保存在栈中的通用寄存器、状态寄存器和栈指针。

```c++
.macro RESTORE_ALL

    LOAD s1, 32*REGBYTES(sp)
    LOAD s2, 33*REGBYTES(sp)

    csrw sstatus, s1
    csrw sepc, s2

    # restore x registers
    LOAD x1, 1*REGBYTES(sp)
    LOAD x3, 3*REGBYTES(sp)
    LOAD x4, 4*REGBYTES(sp)
    LOAD x5, 5*REGBYTES(sp)
    LOAD x6, 6*REGBYTES(sp)
    LOAD x7, 7*REGBYTES(sp)
    LOAD x8, 8*REGBYTES(sp)
    LOAD x9, 9*REGBYTES(sp)
    LOAD x10, 10*REGBYTES(sp)
    LOAD x11, 11*REGBYTES(sp)
    LOAD x12, 12*REGBYTES(sp)
    LOAD x13, 13*REGBYTES(sp)
    LOAD x14, 14*REGBYTES(sp)
    LOAD x15, 15*REGBYTES(sp)
    LOAD x16, 16*REGBYTES(sp)
    LOAD x17, 17*REGBYTES(sp)
    LOAD x18, 18*REGBYTES(sp)
    LOAD x19, 19*REGBYTES(sp)
    LOAD x20, 20*REGBYTES(sp)
    LOAD x21, 21*REGBYTES(sp)
    LOAD x22, 22*REGBYTES(sp)
    LOAD x23, 23*REGBYTES(sp)
    LOAD x24, 24*REGBYTES(sp)
    LOAD x25, 25*REGBYTES(sp)
    LOAD x26, 26*REGBYTES(sp)
    LOAD x27, 27*REGBYTES(sp)
    LOAD x28, 28*REGBYTES(sp)
    LOAD x29, 29*REGBYTES(sp)
    LOAD x30, 30*REGBYTES(sp)
    LOAD x31, 31*REGBYTES(sp)
    # restore sp last
    LOAD x2, 2*REGBYTES(sp)
    .endm
```

最后执行 `sret` 指令，CPU 会将程序计数器（`sepc`）恢复为中断发生前的地址，并回到原先的特权级继续执行被打断的指令流。

执行 `sret` 时硬件自动完成：

1. **将 `sepc` 的值加载到 PC 中** —— 即恢复到中断前的那条指令地址；

2. **恢复 SSTATUS 寄存器的模式位（SPP）** —— 决定返回到用户态或内核态；

3. **重新启用中断（根据 SIE 位）**。

至此一次时钟中断的完整处理与返回过程结束。

### 扩展练习 Challenge 1：描述与理解中断流程

#### **问题 1：描述 ucore 中处理中断异常的流程。**

1. **在trap发生时，硬件做了什么？主要分为下面三个方面。**

* **更新了三个控制状态寄存器CSR：**

sepc：将被打断的指令的地址存到sepc寄存器。

scause：将trap的类型存入scause寄存器，是中断还是异常？

stval：存储和trap有关的额外的细节，取决于scause。

* **切换状态并屏蔽中断（sstause寄存器）**

这个sstause寄存器记录了S模式的运行状态。

sstause.SPP：trap发生之前的特权级，如果SPP=0就表示trap来自U模式，如果SPP=1表示trap来自S模式。后续通过sret读取这个位来返回trap发生前的模式。

stause.SPIE：用来保存trap发生前的SIE的状态，就是中断开关原来是否是打开的。

stause.SIE：这个是在S模式下的SIE的状态，当SIE=1的时候说明响应模式中断，当SIE=0就说明不允许响应中断。

stause.SPIE \&stause.SIE：先将SIE存入SPIE，然后强制SIE为0（为了防止中断嵌套）

切换模式：将cpu特权级切换到S级。

* **跳转到入口，CPU开始执行软件处理**

在内核初始化的时候会把stvec的值设成\_alltraps的地址。

然后当trap发生时，硬件会把CPU的pc值设成stvec中存储的地址，所以CPU就从\_alltraps开始执行指令，进入内核trap部分。

\_alltraps部分的汇编代码通过中断帧将底层硬件状态和寄存器信息打包发给C函数的trap处理。

* **进入汇编代码（就是上面提到的trapentry.S部分的\_alltraps部分）**

- **形成中断帧**

步骤1的硬件记录了一些寄存器，那么接下来就由汇编记录剩下的通用寄存器，将完整的记录作为作为中断帧传递给C函数。下面的这个trapframe就是一个中断帧结构体，记录了4+32个寄存器的信息。

```c++
struct trapframe {
    struct pushregs gpr;  //通用寄存器
    uintptr_t status;    //状态寄存器
    uintptr_t epc;   //异常程序计数器
    uintptr_t badvaddr;   //出错的虚拟地址
    uintptr_t cause;   //中断原因
};
```

* **SAVE\_ALL宏**

这部分负责将trap发生前所有的寄存器的关键状态按照中断帧的格式存在内核栈里（为什么不能存在用户栈里呢，因为用户栈会有缺页风险，关键信息还是存在内核栈吧）(我直接在代码里以注释的格式讲解过程）

```sql
.macro SAVE_ALL 
##这个意思就是栈是S模式下的内核栈

csrw sscratch, sp
##这个是把trap发生前的sp存到sscratch寄存器里，因为后续要用到sp为中断帧分配空间，所以先存一下初始值

addi sp, sp, -36 * REGBYTES
##为了给中断帧预留出一块连续内存 sp向低地址移动，空出36*8个字节

STORE x0, 0*REGBYTES(sp)
STORE x1, 1*REGBYTES(sp)
STORE x3, 3*REGBYTES(sp)
....
##store把除了x2的31个通用寄存器存到中断帧

csrr s1, sstatus
csrr s2, sepc
csrr s3, sbadaddr
csrr s4, scause
STORE s1, 32*REGBYTES(sp)
STORE s2, 33*REGBYTES(sp)
STORE s3, 34*REGBYTES(sp)
STORE s4, 35*REGBYTES(sp)
##把CSR存到中断帧，具体实现就是将CSR寄存器的值读到通用寄存器，再通过store指令将其镀金内存。

csrrw s0, sscratch, x0
STORE s0, 2*REGBYTES(sp)
##这部分就是将保存初始的sp，这个sp已经被我们存在了sscratch寄存器里了，所以将sscratch寄存器的值赋给s0，再将其存到x2的位置。
```

* `move a0, sp` 执行：见问题2。

* `jal trap` 执行：跳转并链接，调用 C 语言函数 trap()。

- **C语言部分**

* **trap（）**

```sql
void trap(struct trapframe *tf) {
    trap_dispatch(tf);
    //调用了trap_dispatch（）函数
}
```

* **trap\_dispatch（）**

```c++
static inline void trap_dispatch(struct trapframe *tf) {
    if ((intptr_t)tf->cause < 0) {
        //这是中断！
        interrupt_handler(tf);
    } else {
        //这是异常！
        exception_handler(tf);
    }
}
```

这段是中断分发，就是判断是中断还是异常！<0就是中断，>0就是异常！然后再跳转到对应的处理函数`interrupt_handler(）`和`exception_handler(）`。

* **interrupt\_handler()\_RQ\_S\_TIMER**

```java
case IRQ_S_TIMER: //这个是时钟中断！
    clock_set_next_event();   //设置下次时钟中断。
    ticks++;  //计数器加1
    if (ticks % TICK_NUM == 0) {  //每中断100次打印一次
        print_ticks();
        num++;
    }
    if (num == 10) {  //打印10次后关机
        sbi_shutdown();
    }
    break;
```

代码太多了我就不全粘了（），主要是通过switch，case对应不同的中断，主要在注释里讲一下时钟中断。

* **trap函数返回**

- **进入汇编返回**

简略的流程就是

* jal返回到\_trapret标签处，

* 再执行RESTORE\_ALL （SAVE\_ALL的逆过程）

从栈帧中加载sstatus和sepc的值到GPR，再通过csrw恢复他们

从栈帧中加载31个寄存器

加载sp(x2)寄存器，sp被恢复，栈帧被释放。

* sret 执行

- **硬件的中断返回**

* 恢复中断的使能状态(sstatus.SIE = sstatus.SPIE)

* 恢复特权级 (current\_priv = sstatus.SPP)

* 跳转回 sepc 寄存器指向的地址 (pc = sepc)

***

#### **问题 2：`move a0, sp` 的目的是什么？**

将sp的值存入a0中，把这个指向中断帧的指针存入a0寄存器，便于将其作为参数传递给trap函数。

***

#### **问题 3：`SAVE_ALL` 中寄存器保存在栈中的位置是什么确定的？**

由`struct trapframe`**&#x20;**&#x7ED3;构体 确定的。

它嵌套的`struct pushregs`函数定义了一个严格的内存布局，严格确定了32个寄存器和4个CSRs的顺序和偏移量。SAVE\_ALL必须硬编码遵循这个布局的规定。

***

#### **问题 4：对于任何中断，`__alltraps` 中都需要保存所有寄存器吗？**

我觉得是的，对于任何中断都要保存所有的寄存器。

因为接下来会调用trap（）函数，它可以修改任意一个寄存器，一旦被修改的寄存器没有存储就糟糕了，所以每一个寄存器都要存储。

***

### 扩展练习 Challenge 2：理解上下文切换机制&#x20;

#### 上下文切换机制

对于上下文切换，我们主要需要完成**两大步骤**：

* 保存CPU的寄存器（上下文）到内存中（栈上）

* 从内存中（栈上）恢复CPU的寄存器

接下来我们分步骤来进行分析和解决。

##### 1. 保存CPU的寄存器（上下文）到内存中（栈上）

**首先，我们需要保存寄存器**，但是cpu的寄存器有几十个，如果挨个写的话很不好管理，于是我们在`kern/trap/trap.h`文件中定义了一个结构体`trapFrame`，它的结构为：

```c++
struct trapframe {
    struct pushregs gpr;
    uintptr_t status; //sstatus
    uintptr_t epc; //sepc
    uintptr_t badvaddr; //sbadvaddr
    uintptr_t cause; //scause
};
```

* `sepc`：保存被中断指令的地址

* `scause`：记录中断/异常原因

* `stval`：提供附加信息（如缺页地址）

* `sstatus`：保存中断使能状态

我们可以看到，在结构体内部第一行又定义了一个结构体` `**`pushregs`，**&#x8FD9;个结构体里面存储的是通用寄存器`x0`到`x31`。这个结构体在`trapFrame`代码上方直接定义。

于是，现在我们已经将需要的通用寄存器以及四个和中断相关的CSR都用一个结构体打包起来了，这样方便管理。接下来，我们要在中断发生时，将寄存器保存到栈上。***如何处理？***

这时我们新建一个文件`kern/trap/trapentry.S`，它的作用是处理中断和异常的入口和退出，进行上下文的保存和恢复。

**首先**我们在文件开头定义一个汇编宏 `SAVE_ALL`, 用来保存所有寄存器到栈顶（实际上把一个trapFrame结构体放到了栈顶）。

```c
.macro SAVE_ALL
```

###### 接着我们进行栈指针备份

```c
csrw sscratch, sp
```

作用：将当前栈指针sp保存到sscratch寄存器中，作为原始sp的临时备份，方便我们最后的恢复。

###### 栈空间分配

`addi sp, sp, -36 * REGBYTES`

**作用**：在栈上分配36个寄存器空间，对应`struct trapframe`的大小

*为什么是36？*

* 32个通用寄存器 + 4个CSR寄存器 = 36个寄存器

###### &#x20;通用寄存器保存

```python
STORE x0, 0*REGBYTES(sp)    # 零寄存器
STORE x1, 1*REGBYTES(sp)    # 返回地址 (ra)
注意：跳过 x2(sp)，特殊处理
STORE x3, 3*REGBYTES(sp)    # 全局指针 (gp)
STORE x4, 4*REGBYTES(sp)    # 线程指针 (tp)
STORE x5, 5*REGBYTES(sp)    # 临时寄存器 t0
... (依次保存 x6-x31)
STORE x31, 31*REGBYTES(sp)  # 临时寄存器 t6
```

关键点：

* x2(sp)被跳过：因为sp正在被修改（sp现在指向新分配的空间），原始sp值在sscratch中，后面会处理。

* 保存顺序：严格按照`struct pushregs`结构体定义顺序

###### CSR寄存器读取和保存

```c
csrrw s0, sscratch, x0     # 读取原始sp到s0，同时清空sscratch
csrr s1, sstatus           # 读取sstatus到s1
csrr s2, sepc              # 读取sepc到s2  
csrr s3, sbadaddr          # 读取stval到s3
csrr s4, scause            # 读取scause到s4
```

关键操作分析：

* `csrrw s0, sscratch, x0`：

  * 原子操作：同时完成读取和写入

  * 读取：将sscratch值（原始sp）读入s0

  * 写入：将x0(0)写入sscratch，标记为"来自内核的中断"

###### 关键寄存器存储到栈帧

```c
STORE s0, 2*REGBYTES(sp)   # 保存原始sp到x2位置
STORE s1, 32*REGBYTES(sp)  # 保存sstatus
STORE s2, 33*REGBYTES(sp)  # 保存sepc
STORE s3, 34*REGBYTES(sp)  # 保存sbadaddr(stval)
STORE s4, 35*REGBYTES(sp)  # 保存scause
```

这样我们就完成了SAVE\_ALL的操作，在中断发生时将CPU的寄存器（上下文）保存到内存中（栈上）

2. **从内存中（栈上）恢复CPU的寄存器**

依旧在` kern/trap/trapentry.S`文件中，进行`RESTORE_ALL`的宏定义来进行上下文的恢复。

###### 第一步：恢复CSR寄存器

```c
LOAD s1, 32*REGBYTES(sp)   # 加载sstatus
LOAD s2, 33*REGBYTES(sp)   # 加载sepc

csrw sstatus, s1           # 恢复sstatus
csrw sepc, s2              # 恢复sepc
```

**为什么只恢复这两个？**

* `sstatus`：控制中断使能状态，必须恢复

* `sepc`：决定返回到哪里执行，必须恢复

* `scause`和`stval`：只是诊断信息，不需要恢复

###### 第二步：恢复通用寄存器（除了sp）

```c
LOAD x1, 1*REGBYTES(sp)    # 恢复ra（返回地址）
LOAD x3, 3*REGBYTES(sp)    # 恢复gp
LOAD x4, 4*REGBYTES(sp)    # 恢复tp
...（依此类推，恢复x5到x31）
```

这里可以看到依旧跳过`x2`,因为sp必须最后恢复，其他寄存器的加载依赖当前sp值。

###### 第三步：最后恢复栈指针

```c
LOAD x2, 2*REGBYTES(sp)    # 最后恢复sp
```

现在sp回到了中断发生前的值，栈也回到了原来的状态。

* **到目前为止，我们完成了上下文切换的核心的两个步骤，接下来我们要在汇编代码里面设置中断处理入口点来实现中断处理。**

```assembly&#x20;language
.globl __alltraps          # 声明为全局符号，其他文件可以访问
.align(2)                  # 4字节对齐（2^2=4）
__alltraps:
    SAVE_ALL               # 第一步：保存所有寄存器

    move  a0, sp           # 第二步：准备参数
    jal trap               # 第三步：调用C处理函数
```

详细步骤：

* `SAVE_ALL`：把所有状态保存起来

* `move a0, sp`：把存档文件的地址（sp指向trapframe）作为参数。

  * RISC-V约定：第一个参数放在a0寄存器，a0寄存器传递参数（把上下文包装成结构体）给接下来调用的函数trap。

* `jal trap`：跳转到C语言的trap函数

  * `jal`会同时把返回地址保存到ra寄存器

  * C函数处理完中断后，会返回到下一条指令（向下继续执行\_\_trapret里面的内容）

- **中断返回点**

```assembly&#x20;language
.globl __trapret
__trapret:
    RESTORE_ALL    # 恢复所有寄存器
    sret           # 特权返回指令
```

详细步骤：

* `RESTORE_ALL`：使用之前定义的宏，把所有状态恢复

* `sret`：这是一条特权指令，用于从S模式返回，完成从内核态到用户态的切换。它会：

  * 从sepc恢复程序计数器（回到中断发生的地方）

  * 恢复中断使能状态

  * 根据保存的特权级回到原来的模式

#### **这样，我们就完成了上下文切换的全部流程！**



**问题 1：`csrw sscratch, sp` 和 `csrrw s0, sscratch, x0` 实现了什么，目的是什么？**

**标准解答：** 这是一个两步操作，其**核心目的**是将**被中断时的栈指针 `sp`** 保存到 `struct trapframe` 的 `gpr.sp` 槽位中。

* **`csrw sscratch, sp`**

  * **实现：** `CSR[sscratch] = sp`。

  * **目的：** `sscratch` 是一个专供 S 模式使用的“暂存器”，硬件在陷阱（Trap）时不会自动修改它。此时的 `sp` 是**被中断上下文的栈指针**。我们马上就要修改 `sp` 来分配中断帧，所以必须先把这个**原始 `sp` 值**保存到一个安全的地方。`sscratch` 就是这个“安全暂存处”。

* **`csrrw s0, sscratch, x0`**

  * **实现：** 这是一条**原子**的“读-改-写”指令。它执行两个操作：

    1. **读：** `s0 = CSR[sscratch]` (把 `sscratch` 的当前值——即原始 `sp`——读入 `s0`)。

    2. **写：** `CSR[sscratch] = x0` (把 `x0` 的值——即 0——写入 `sscratch`)。

  * **目的：**

    1. **(读) 准备写入：** 将原始 `sp` 值从“暂存处” `sscratch` 转移到“通用寄存器” `s0` 中，以便**下一步** `STORE s0, 2*REGBYTES(sp)` 指令能将其存入中断帧的 `sp` 槽位。

    2. **（写）遵守约定 (可选但良好)：** 将 `sscratch` 清零。在 ucore 中（如 `idt_init` 所示），有一个约定：`sscratch` 为 0 表示中断来自 S 模式。这一步在 S 模式自陷时（如时钟中断）顺便重置了这个约定。

***

**问题 2：为什么 `SAVE_ALL` 保存了 `stval` `scause`，而 `RESTORE_ALL` 却不还原它们？**

**标准解答：因为它们是“事故报告”，而不是“返回配置”。**

* **`SAVE_ALL` 的目的 (保存)：**

  * `scause` (原因), `stval` (值), `sepc` (地址) 是硬件在异常发生时**自动生成**的“事故报告”。

  * `SAVE_ALL` 把它们从 CSR 保存到 `struct trapframe`（内存）中，**目的是为了让 C 语言代码 (`trap.c`) 能够“阅读”这份报告**。

  * `trap_dispatch` **必须**读取 `tf->cause` 才能知道如何分发。`exception_handler` **必须**读取 `tf->epc` 和 `tf->badvaddr` 才能打印有用的调试信息。

* **`RESTORE_ALL` 的目的 (不还原)：**

  * `sret`（中断返回）指令**只关心**两个 CSR：`sepc` 和 `sstatus`。

    * `sepc` 告诉 `sret` **要返回到哪里**。

    * `sstatus` 告诉 `sret` **要返回到什么特权级**以及**是否要重开中断**。

  * `sret` 指令**完全不关心 `scause` 和 `stval` 的值**。

  * 你无法“还原”一个异常的原因。`scause` 和 `stval` 是硬件在**进入**中断时“写入”的，软件在**处理**中断时“读取”的。它们在**返回**（`sret`）时没有任何作用。因此，恢复它们既无必要，也无意义。

**问题 3：store的意义何在？**

sbadaddr (stval) 和 scause 是**只读**的寄存器，它们由硬件在中断发生时设置，虽然恢复他们并没有用处（因为当再次发生中断时，硬件会重新设置它们），但是它们也是**需要保存**的，因为在中断处理函数中，我们可&#x80FD;***需要这些信息来处理中断***。例如，在缺页异常中，我们需要知道缺页的地址；在系统调用中，我们需要知道是系统调用异常（虽然scause会被保存，但系统调用通常通过ecall指令，其异常代码是固定的）。我们将它们保存在栈上，这样在C语言的中断处理函数中，可以通过trapframe结构体来访问这些值。

***



### 扩展练习 Challenge 3：完善异常中断&#x20;

这部分就是完善trap.c文件中的`exception_handler` 函数，能够正确捕获并处理非法指令和断点这两种同步异常。

#### 主要的步骤包括：触发异常，捕获异常，处理并返回。

1. 主动触发异常

&#x20;为了验证异常处理器，我首先需要在内核中主动触发这两种异常。我修改了 `init.c` 文件，创建了一个 `test_exceptions` 函数，并在 `kern_init` 主流程中调用它 。

* **非法指令**：通过内联汇编 `asm volatile(".word 0x00000000");`来执行一条全零的、CPU 无法识别的指令。

* **断点**：通过内联汇编 `asm volatile("ebreak");` 来执行 `ebreak` 指令，这会主动产生一个断点异常。

- 捕获并处理异常

当上述指令执行时，CPU 会自动停止当前流程，保存 `sepc`（异常指令的地址）和 `scause`（异常原因），然后跳转到 `__alltraps`，最终调用 `exception_handler`。 我在 `exception_handler` 中添加了两个 `case` 分支：

* `case CAUSE_ILLEGAL_INSTRUCTION:`用于处理 `scause` 为“非法指令”的情况。

* `case CAUSE_BREAKPOINT:` 用于处理 `scause` 为“断点”的情况。

- 关键核心问题

在debug的过程中，下面这部分花费了较长时间发现问题并修改

同步异常和中断不一样，`sepc` 寄存器保存的是**导致异常的指令本身**的地址。如果在处理后直接返回，CPU 会**再次执行**同一条异常指令，导致**无限循环**。所以必须在case分支中修改`trapframe` 结构体中的 `epc` 成员，即 `tf->epc`，使其指向异常指令的**下一条**指令。

* 对于非法指令，是四字节长，直接将epc+4。`tf->epc += 4;`

* 对于断点，经过修改和调试，发现这是一条2字节的RISC-V的压缩指令，所以epc+2。`tf->epc += 2;`

#### **关键代码实现**

触发异常：

```c++
// kern/init/init.c

int kern_init(void) {
    // ... (省略其他初始化代码) ...
    intr_enable();  // enable irq interrupt

    cprintf("Before calling test_exceptions()\n");
    
    //在 kern_init 中调用：
    test_exceptions();
    
    cprintf("After calling test_exceptions() - should not reach here if infinite loop\n");
    
    /* do nothing */
    while (1)
        ;
}

void test_exceptions(void) {
    // 测试非法指令异常
    cprintf("Testing illegal instruction exception...\n");
    asm volatile(".word 0x00000000");  // 非法指令
    
    // 测试断点异常
    cprintf("Testing breakpoint exception...\n");
    asm volatile("ebreak");
    
    cprintf("All exception tests passed!\n");
    return;
}
```

处理异常：

```c++
void exception_handler(struct trapframe *tf) {
    switch (tf->cause) {
        // ......

        case CAUSE_ILLEGAL_INSTRUCTION:  //非法指令异常处理
            // 非法指令异常处理
            cprintf("Illegal instruction caught at 0x%08x\n", tf->epc);
            cprintf("Exception type: Illegal instruction\n");
            cprintf("Before update: epc = 0x%08x\n", tf->epc);
            
            // 关键：跳过4字节的非法指令
            tf->epc += 4; 
            
            cprintf("After update: epc = 0x%08x\n", tf->epc);
            break;

        case CAUSE_BREAKPOINT:  //断点
            //断点异常处理
            cprintf("=== BREAKPOINT EXCEPTION ===\n");
            cprintf("ebreak caught at 0x%08x\n", tf->epc);
            cprintf("Exception type: breakpoint\n");
            cprintf("Before update: epc = 0x%08x\n", tf->epc);
    
            // (额外的调试信息)
            uint32_t *instr_ptr = (uint32_t *)tf->epc;
            cprintf("Instruction at epc: 0x%08x\n", *instr_ptr);
    
            // 关键：跳过2字节的 c.ebreak 压缩指令
            tf->epc += 2;
            
            cprintf("After update: epc = 0x%08x\n", tf->epc);
    
            // (额外的调试信息)
            cprintf("Stack pointer: 0x%08x\n", tf->gpr.sp);
            cprintf("Return address: 0x%08x\n", tf->gpr.ra);
            break;

        // ......

        default:
            print_trapframe(tf);
            // 确保未处理的异常不会无限循环
            panic("unhandled exception");
            break;
    }
}
```

#### 执行结果与分析

![](images/image.png)

1. **`Illegal instruction caught at 0xc0200064`**：内核在 `...64` 地址触发了非法指令异常。

2. **`After update: epc = 0xc0200068`**：我的处理代码将 `epc` (返回地址) 成功修改为 `...68`（即 `...64 + 4`）。

3. **`Testing BREAKPOINT exception...`**：这行日志在 `init.c` 的非法指令之后，它的出现证明了内核**没有**陷入无限循环，而是成功返回并继续执行 `test_exceptions` 函数。

4. **`ebreak caught at 0xc0200074`**：内核接着在 `...74` 地址触发了断点异常。

5. **`After update: epc = 0xc0200076`**：我的处理代码将 `epc` 成功修改为 `...76`（即 `...74 + 2`）。

6. **`All exception tests passed!`**：这行日志在 `ebreak` 之后，它的出现证明了内核再次成功返回，`test_exceptions` 函数得以执行完毕。

7. **`100 ticks`**：最后，内核稳定地回到了 `kern_init` 的主循环，并开始正常处理时钟中断，证明整个系统在经历两次异常后依然保持稳定。

**结论：** 通过在 `exception_handler` 中正确捕获异常 `case`，并修改 `tf->epc` 来跳过异常指令，我们成功地实现了 Challenge 3 的要求！
