**所有人在完成基础框架的理解之后，对实验任务进行了如下的分工：**

**苏奕扬**负责练习1和练习2主体代码和报告的书写，challenge2算法设计部分的报告书写。

**侯懿轩**负责challenge2的主体代码以及测试数据的书写，对challenge1进行部分修改以及报告的书写。

**姚鑫秋**负责challenge1的主体代码以及测试数据的书写，后期修改bug以及报告的书写，以及challenge3的资料的查找和报告的书写。

# 练习1：理解first-fit 连续物理内存分配算法

## 算法概述

在 *首次适应（First Fit）算法* 中，分配器维护一个空闲块列表。当接收到一个内存分配请求时，它从空闲块链表头开始扫描，找到第一个足够大的块来满足请求。如果找到的块明显大于所需大小，则通常会将其拆分，前半部分用于分配，剩余部分重新作为一个新的空闲块加入到空闲链表中。

## 代码分析

### default\_init

```c
default_init(void) {
    list_init(&free_list);
    nr_free = 0;
}
```

该函数用于初始化存放空闲块的链表。首先调用**list\_init**函数，初始化一个空的双向链表**free\_list**，并将空闲页数置 0。**list\_init**函数定义如下：

```c++
static inline void
list_init(list_entry_t *elm) {
    elm->prev = elm->next = elm;
}
```

### default\_init\_memmap

```c
static void
default_init_memmap(struct Page *base, size_t n) {
    assert(n > 0);
    struct Page *p = base;
    for (; p != base + n; p ++) {
        assert(PageReserved(p));
        p->flags = p->property = 0;
        set_page_ref(p, 0);
    }
    base->property = n;
    SetPageProperty(base);
    nr_free += n;
    if (list_empty(&free_list)) {
        list_add(&free_list, &(base->page_link));
    } else {
        list_entry_t* le = &free_list;
        while ((le = list_next(le)) != &free_list) {
            struct Page* page = le2page(le, page_link);
            if (base < page) {
                list_add_before(le, &(base->page_link));
                break;
            } else if (list_next(le) == &free_list) {
                list_add(le, &(base->page_link));
            }
        }
    }
}
```

该函数负责初始化 `[base, base + n)` 范围的物理页为一个新的空闲块。首先确保请求的页数 `n` 大于 0。若 `n==0`，就不需要存放了。

然后遍历 `[base, base + n)` 范围内的每一页：

1. `assert(PageReserved(p));`&#x20;

确认这些页此前被标记为保留。这是一个安全检查，保证不会把不应当初始化的页当作 free。

* `p->flags = p->property = 0;`&#x20;

&#x20;将页标志和 `property` 字段设置为0。`property` 为 0 表示默认不是块头。

* `set_page_ref(p, 0);`

引用计数清 0（空闲页没有引用）。

set\_page\_ref函数的功能是，将给定Page结构体指针所指向的页面的引用计数为指定的值。

```c++
static inline void set_page_ref(struct Page *page, int val) { page->ref = val; }
```

然后，将首个页面的property属性设置为n，也就是对应的块总数。然后设置页面的属性值。最后，更新&#x20;

nr\_free的数量为n。

后面的if函数用于判断该列表是否为空：&#x20;

* 如果空闲页面链表为空，则将起始页面的链表节点添加到链表中。&#x20;

* 如果空闲页面链表不为空，则遍历链表找到合适的位置插入新的页面链表节点。具体是在链表中找到第一个地址大于base的页面，如果找到了就在该页面之前插入新的链表节点(使用list\_add\_before函数)；如果遍历完链表也没有找到这样的页面，则将新的链表节点添加到链表末尾 (使用list\_add函数)。

```c++
static inline void
list_add(list_entry_t *listelm, list_entry_t *elm) {
    list_add_after(listelm, elm);
}
static inline void
list_add_before(list_entry_t *listelm, list_entry_t *elm) {
    __list_add(elm, listelm->prev, listelm);
}
```

### default\_alloc\_pages

```c
static struct Page *
default_alloc_pages(size_t n) {
    assert(n > 0);
    if (n > nr_free) {
        return NULL;
    }
    struct Page *page = NULL;
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        if (p->property >= n) {
            page = p;
            break;
        }
    }
    if (page != NULL) {
        list_entry_t* prev = list_prev(&(page->page_link));
        list_del(&(page->page_link));
        if (page->property > n) {
            struct Page *p = page + n;
            p->property = page->property - n;
            SetPageProperty(p);
            list_add(prev, &(p->page_link));
        }
        nr_free -= n;
        ClearPageProperty(page);
    }
    return page;
}
```

该函数从空闲链表中寻找第一个能满足 `n` 页需求的块。若找到块则从链表中删除该空闲块头，并且判断块是否大于需求，若大于则拆分剩余部分，把剩余部分重新插入链表。最后，减少 nr\_free计数，并标记已分配的页面。

### default\_free\_pages

```c
static void
default_free_pages(struct Page *base, size_t n) {
    assert(n > 0);
    struct Page *p = base;
    for (; p != base + n; p ++) {
        assert(!PageReserved(p) && !PageProperty(p));
        p->flags = 0;
        set_page_ref(p, 0);
    }
    base->property = n;
    SetPageProperty(base);
    nr_free += n;

    if (list_empty(&free_list)) {
        list_add(&free_list, &(base->page_link));
    } else {
        list_entry_t* le = &free_list;
        while ((le = list_next(le)) != &free_list) {
            struct Page* page = le2page(le, page_link);
            if (base < page) {
                list_add_before(le, &(base->page_link));
                break;
            } else if (list_next(le) == &free_list) {
                list_add(le, &(base->page_link));
            }
        }
    }

    list_entry_t* le = list_prev(&(base->page_link));
    if (le != &free_list) {
        p = le2page(le, page_link);
        if (p + p->property == base) {
            p->property += base->property;
            ClearPageProperty(base);
            list_del(&(base->page_link));
            base = p;
        }
    }

    le = list_next(&(base->page_link));
    if (le != &free_list) {
        p = le2page(le, page_link);
        if (base + base->property == p) {
            base->property += p->property;
            ClearPageProperty(p);
            list_del(&(p->page_link));
        }
    }
}
```

该函数负责释放 `[base, base + n)` 的页并尝试合并相邻空闲块。如果当前页未被标为 reserved 且不是其它空闲块的头，就重置页面的对应属性，将引用设置定义为0，并更新空闲块数的数量。然后将页面添加到空闲块列表中，同时尝试合并相邻的空闲块。如果释放的页面与前一个页面或后一个页面相邻，会尝试将它们合并为一个更大的空闲块。

### default\_nr\_free\_pages

```c
static size_t
default_nr_free_pages(void) {
    return nr_free;
}
```

该函数用于获取当前空闲页总数。

### 测试函数：basic\_check和default\_check

```c++
static void
basic_check(void) {
    struct Page *p0, *p1, *p2;
    p0 = p1 = p2 = NULL;
    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(p0 != p1 && p0 != p2 && p1 != p2);
    assert(page_ref(p0) == 0 && page_ref(p1) == 0 && page_ref(p2) == 0);

    assert(page2pa(p0) < npage * PGSIZE);
    assert(page2pa(p1) < npage * PGSIZE);
    assert(page2pa(p2) < npage * PGSIZE);

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    assert(alloc_page() == NULL);

    free_page(p0);
    free_page(p1);
    free_page(p2);
    assert(nr_free == 3);

    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(alloc_page() == NULL);

    free_page(p0);
    assert(!list_empty(&free_list));

    struct Page *p;
    assert((p = alloc_page()) == p0);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    free_list = free_list_store;
    nr_free = nr_free_store;

    free_page(p);
    free_page(p1);
    free_page(p2);
}
```

该函数用于测试最基本的页分配或释放逻辑，验证链表初始化、nr\_free 计数、重复分配与回收，确保`alloc_page()` 和 `free_page()` 能正常配合。

```c++
static void
default_check(void) {
    int count = 0, total = 0;
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        assert(PageProperty(p));
        count ++, total += p->property;
    }
    assert(total == nr_free_pages());

    basic_check();

    struct Page *p0 = alloc_pages(5), *p1, *p2;
    assert(p0 != NULL);
    assert(!PageProperty(p0));

    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));
    assert(alloc_page() == NULL);

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    free_pages(p0 + 2, 3);
    assert(alloc_pages(4) == NULL);
    assert(PageProperty(p0 + 2) && p0[2].property == 3);
    assert((p1 = alloc_pages(3)) != NULL);
    assert(alloc_page() == NULL);
    assert(p0 + 2 == p1);

    p2 = p0 + 1;
    free_page(p0);
    free_pages(p1, 3);
    assert(PageProperty(p0) && p0->property == 1);
    assert(PageProperty(p1) && p1->property == 3);

    assert((p0 = alloc_page()) == p2 - 1);
    free_page(p0);
    assert((p0 = alloc_pages(2)) == p2 + 1);

    free_pages(p0, 2);
    free_page(p2);

    assert((p0 = alloc_pages(5)) != NULL);
    assert(alloc_page() == NULL);

    assert(nr_free == 0);
    nr_free = nr_free_store;

    free_list = free_list_store;
    free_pages(p0, 5);

    le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        count --, total -= p->property;
    }
    assert(count == 0);
    assert(total == 0);
}
```

进一步测试**first-fit算法**的正确性，检查**多页分配、部分释放、合并空闲块、碎片化处理**等复杂场景。

### 结构体default\_pmm\_manager

```c
const struct pmm_manager default_pmm_manager = {
    .name = "default_pmm_manager",
    .init = default_init,
    .init_memmap = default_init_memmap,
    .alloc_pages = default_alloc_pages,
    .free_pages = default_free_pages,
    .nr_free_pages = default_nr_free_pages,
    .check = default_check,
};
```

这个结构体用于内存管理相关的功能，其中包含了多个函数指针和一个字符串成员。：

* .name = "default\_pmm\_manager" ：用于标识这个内存管理器的名称。&#x20;

* .init = default\_init ：函数指针，用于初始化内存管理器的某些状态。&#x20;

* .init\_memmap = default\_init\_memmap ：函数指针，用于设置内存页面的初始状态。&#x20;

* .alloc\_pages = default\_alloc\_pages ：函数指针，指向一个用于分配页面的函数。&#x20;

* .free\_pages = default\_free\_pages ：函数指针，指向一个用于释放页面的函数。&#x20;

* .nr\_free\_pages = default\_nr\_free\_pages ：函数指针，指向一个用于获取空闲页面数量的函&#x20;

数。&#x20;

* .check = default\_check ：函数指针，用于内存分配情况的检查。

## First Fit算法的改进方向

1. **更高效的内存块合并策略**
   &#x20;在释放内存时，通过快速检测相邻空闲块并进行合并，减少外部碎片，提高整体内存利用率。

2. **更快速的空闲块搜索算法**
   &#x20;可以使用有序链表、平衡二叉树或分级空闲链表等结构，实现对空闲块的高效定位。若空闲块按大小排序，还可采用二分查找加速匹配过程。

3. **优化的内存回收与再利用机制**
   &#x20;引入延迟合并（deferred coalescing）或垃圾回收（garbage collection）策略，在系统空闲时再执行块合并，平衡性能与碎片率。

4. **更灵活的内存分配策略**
   &#x20;在First Fit基础上，可进一步实现Next Fit、Best Fit、Buddy System等算法，根据分配模式与应用场景灵活选择，提高分配效率与内存利用率。

# 练习2：实现 Best-Fit 连续物理内存分配算法

不同于First-Fit算法，Best-Fit是在所有空闲块中，找到**最小的、但仍能满足请求大小**的空闲块进行分配。因此需要描整个空闲链表，找到最合适的块。

```c
while ((le = list_next(le)) != &free_list) {
    struct Page *p = le2page(le, page_link);
    if (p->property >= n && p->property < min_size) {
        page = p;
        min_size=p->property;//更新min_size
        //区别于First-Fit，去掉break
    }
}
```

使用框架给出的min\_size来记录最小块数的值，在循环过程中，如果有比当前的块小的，就更新min\_size，直到循环结束，我们就找到了最小的块，并将最小块数的p值存储在page变量中。其余部分与First-Fit算法相同。

使用make grade进行测试，结果如下图所示：

![](<images/屏幕截图 2025-10-17 112053.png>)

## Best-Fit算法的改进方向

1. **更高效的空闲块查找策略**

在分配内存时，通过有序链表、平衡二叉树或分级空闲链表等数据结构，实现对最合适空闲块的快速定位，减少遍历时间，提高分配效率。

* **优化的内存块合并机制**

在释放内存时，快速检测前后相邻空闲块并进行合并，同时可引入延迟合并（deferred coalescing）策略，减少操作开销，提高连续空闲内存的利用率。

* **降低外部碎片的策略**

通过定期内存紧凑（compaction）或小块合并，减少小碎片的产生，提高可用内存的连续性与整体利用率。

* **更智能的分配策略**

在Best-Fit基础上，可结合Next-Fit、Buddy System或自适应分配策略，根据应用场景和分配模式动态调整选择，提高内存分配效率和系统性能。

# Challenge1：实现buddy system（伙伴系统）分配算法

## 一、设计文档

### 1.设计目标

目标是在 ucore 操作系统的物理内存管理（PMM）框架下，实现经典的伙伴系统内存分配算法。伙伴系统通过将内存划分为 $$2^n$$ 大小的块进行管理，利用块的**分裂**满足**小内存请求**，并通过块的**合并**来减少**外部碎片**，来达到较高的内存利用率和分配效率。

### 2.数据结构的设计

为了实现伙伴系统，我们对原有的PMM数据结构进行了调整和拓展，让它能够适应伙伴系统的管理模式。

1. 空闲链表数组

伙伴系统的核心是按照块的大小对空闲内存进行分类管理，所以我们使用free\_area\_t类型的数组来组织空闲块。在buddy\_pmm.c中定义如下

```c++
// 定义最大阶数
#define MAX_ORDER 15

// 空闲链表数组的定义
static free_area_t free_area[MAX_ORDER];

// 辅助宏，方便访问
#define free_list_at(order) (free_area[order].free_list)
#define nr_free_at(order) (free_area[order].nr_free)
```

`MAX_ORDER`宏定义为 15。这是因为系统总内存约为 128MB，页大小为 4KB，总页数约为 32768 页。 $$2^{15} $$=32768，所以15阶就可以管理所有可能的内存块。（从 $$2^0$$到 $$2^{14}$$页）

`free_area[k]`用来管理所有大小为 $$2^k$$页的空闲块，每个`free_area_t`结构体（在`memlayout.h`中定义了)包含一个链表头`free_list`和一个计数器`nr_free`.

* 复用`struct Page` 的 `property` 字段

我们复用了`struct Page`中的`unsigned int property`字段来存储伙伴系统的核心信息。

在我们的伙伴系统中，如果一个Page结构体代表一个内存块的起始页，则其`property`字段存储该块的阶数k，代表这个块大小为 $$2^k$$。

同时，`PG_property`标志位仍然用于标记一个Page是否是空闲页的起始页，这可以让`free`函数在检查伙伴块的时候可以快速判断它是不是空闲的。

### 3.核心函数&算法流程 的设计

基于上面的数据结构，我们实现了`pmm_manager`接口需要的各个函数。

1. **`buddy_init（）`和`buddy_init_memmap()`负责初始化**

`buddy_init()`：遍历`free_area`数组，将所有阶数的空闲链表初始化为空链表，然后把各阶的`nr_free`计数清零。

`buddy_init_memmap(struct Page *base, size_t n)`：此函数负责将 `pmm_init` 探测到的初始连续空闲内存（共 `n` 页）加入伙伴系统。 为了从根本上解决内存块的对齐问题，我们采用了一种“自底向上”的初始化策略：

首先，将 `n` 个页面的 `flags` 和引用计数清零，并将它们的初始阶数（`property`）都设置为 `0`。

然后，遍历这 `n` 个页面，**逐个调用 `free_pages(p, 1)` 函数**。

`free_pages` 的合并逻辑会自动检查每个页面的伙伴。如果伙伴也已经被“释放”，它们就会被合并成一个 `order 1` 的块。这个 `order 1` 的块会继续尝试与它的伙伴合并，以此类推。

```c++
static void buddy_init_memmap(struct Page *base, size_t n) {
    assert(n > 0);
    
    // 1. 初始化所有页面
    for (struct Page *p = base; p != base + n; p++) {
        assert(PageReserved(p));
        p->flags = 0; 
        // 将每个页面的初始阶数设为 0
        p->property = 0; 
        set_page_ref(p, 0);
    }

    // 2. 遍历所有页面，调用 free_pages
    //    free_pages 会读取 p->property (为 0)，
    //    并自动触发合并逻辑，构建出正确对齐的 O1, O2, O3... 块
    for (struct Page *p = base; p != base + n; p++) {
        // free_pages 接口是 (base, n)，但我们的 buddy_free_pages
        // 实际上只使用 base 和 base->property。
        // 传递 n=1 是安全的。
        free_pages(p, 1);
    }
}
```

这个过程利用了 `free_pages` 强大的合并能力，自动将 `n` 个离散的页面组合成了一系列**完全对齐**的、大小为  $$2^k$$的空闲块，构成了伙伴系统的初始状态。由于总页数 `n` (在我的系统中是 `31929`) 不是2的整数次幂，所以初始状态会由多个不同阶的块组成。

* `buddy_alloc_pages(size_t n)`负责分裂与分配

分配函数是伙伴系统实现分裂机制的具体体现，详细的算法实现过程如下

首先，**计算**满足n页所需要的**最小阶数order**，然后从order阶开始，向上查找**第一个非空的空闲链表**（current\_order从order到MAX\_Order-1)。if**找不到**，则内存不足发明会**NULL**。if**找到了**就从找到的`current_order`阶链表中**取出一个大块page**。如果`current_order`大于order，就进入while循环进行**递归分裂**。

```c++
while (current_order > order) {
        current_order--;

        // 1. 使用与 __get_buddy 相同的 XOR 逻辑来找到伙伴
        uintptr_t page_idx = page - pages;
        uintptr_t buddy_idx = page_idx ^ (1 << current_order);
        struct Page *buddy_page = &pages[buddy_idx];

        // 2. 我们总是保留(继续拆分)地址较低的块，并将地址较高的块放入空闲链表
        struct Page *page_to_free;
        if (page < buddy_page) {
            page_to_free = buddy_page;
            // 'page' 已经是较低的块，不需要改变
        } else {
            page_to_free = page;
            page = buddy_page; // 'buddy_page' 是较低的块，我们保留它
        }
        
        // 3. 将地址较高的块(page_to_free)加入空闲链表
        page_to_free->property = current_order;
        SetPageProperty(page_to_free);
        list_add(&free_list_at(current_order), &(page_to_free->page_link));
        nr_free_at(current_order)++;
    }
```

**使用正确的伙伴计算逻辑**：通过 `uintptr_t buddy_idx = page_idx ^ (1 << current_order);` 来计算伙伴的地址，这与 `__get_buddy` 函数完全一致，保证了分配和释放在逻辑上对称。

**保留低地址块**：在分裂时，代码会比较 `page` 和其伙伴 `buddy_page` 的地址，总是将**地址较高**的块放入对应阶数的空闲链表，并保留**地址较低**的块进行下一步分裂或最终分配。这确保了合并逻辑的正确性。

* `buddy_free_pages(struct Page *base, size_t n)`负责释放和合并。

算法的核心是一个 `while` 循环，可持续地进行合并直到无法合并为止：

首先，从base->property获取要释放的块的阶数order，然后在 `while` 循环中，调用 `__get_buddy()` 函数找到当前块的伙伴。

```c++
// buddy_pmm.c
static struct Page* __get_buddy(struct Page *page) {
    size_t order = page->property;
    if (order >= MAX_ORDER - 1) { return NULL; }
    // 利用指针运算直接获取页在全局数组中的索引
    uintptr_t page_idx = page - pages;
    // 通过异或运算找到伙伴的索引
    uintptr_t buddy_idx = page_idx ^ (1 << order);
    // 从全局数组中直接返回伙伴指针
    return &pages[buddy_idx];
}
```

> 该函数通过指针运算 `page - pages` 高效地获取当前页在全局 `pages` 数组中的索引，然后通过位异或（XOR）运算 `^ (1 << order)` 精确地计算出其伙伴的索引，最后返回伙伴的 `Page` 指针。这个方法保证了计算的正确性和高效性。

然后检查合并条件，在while循环中检查伙伴是否满足合并条件，就是检查是否**存在&是空闲的&阶数相同**。

如果满足条件就把伙伴从空闲链表中移除，确定新块的头部（地址较小的），然后把order+1，继续while循环，尝试与新合并的更大的块的伙伴进行合并。不满足直接break循环。

最后，在循环结束后，将最终的块加入其所属阶数的空闲链表中。

```c++
static void buddy_free_pages(struct Page *base, size_t n) {
    assert(n > 0);
    // 从 page->property 获取块的真实阶数 (order)
    size_t order = base->property;
    // 循环尝试与伙伴合并
    while (order < MAX_ORDER - 1) {
        // 1. 找到伙伴
        struct Page *buddy_page = __get_buddy(base);

        // 2. 检查伙伴是否满足合并条件
        if (buddy_page == NULL || !PageProperty(buddy_page) || buddy_page->property != order) {
            break; // 伙伴不空闲或大小不同，停止合并
        }

        // 3. 执行合并：从空闲链表中移除伙伴
        list_del(&(buddy_page->page_link));
        nr_free_at(order)--;
        ClearPageProperty(buddy_page);

        // 4. 确定新块的头部（总是地址较小的那个）
        if (buddy_page < base) {
            base = buddy_page;
        }

        // 5. 新块的阶数加一，并更新 property 以便下一次循环正确工作
        order++;
        base->property = order;
    }

    // 将最终的块（可能已被合并过多次）加入到它所属阶数的空闲链表中
    SetPageProperty(base);
    list_add(&free_list_at(order), &(base->page_link));
    nr_free_at(order)++;
}
```



## 二、测试用例&结果分析

为了验证我们的代码对不对，我们设计了buddy\_check测试函数，然后通过show\_buddy\_info函数打印关键状态，下面是对我们的代码和输出结果的详细分析。

首先，我的系统在初始化后，总可用空闲页为 **31929** 页。由于这个数不是2的整数次幂，`buddy_init_memmap` 正确地将其初始化为多个不同阶的块，这是所有测试的**初始状态**和**最终目标状态**：

```sql
Total free pages: 31929   
Order  0 (size     1): 1 blocks   
Order  3 (size     8): 1 blocks   
Order  4 (size    16): 1 blocks   
Order  5 (size    32): 1 blocks   
Order  7 (size   128): 1 blocks   
Order 10 (size  1024): 1 blocks   
Order 11 (size  2048): 1 blocks   
Order 12 (size  4096): 1 blocks   
Order 13 (size  8192): 1 blocks   
Order 14 (size 16384): 1 blocks
```

### 测试场景1：简单分配&顺序释放

#### 1. 测试函数代码

通过`check_simple_alloc_free` 函数，连续分配 3 个块（请求大小 5, 7, 5 页），然后按分配顺序依次释放。

```c++
// buddy_pmm.c - check_simple_alloc_free()
struct Page *p0 = alloc_pages(5); 
struct Page *p1 = alloc_pages(7); 
struct Page *p2 = alloc_pages(5);
...
free_pages(p0, 5);
free_pages(p1, 7);
free_pages(p2, 5);
```

我们设计这个测试用例是为了验证基本的的分裂逻辑和简单的合并逻辑

#### 2. **结果分析**

**分配阶段：**&#x8BF7;求5、7、5页，实际需要3个8页（`order 3`）的块。系统正确地从初始空闲块中获取并分裂出所需内存。

```sql
------------ After allocating 3 blocks (5, 7, 5 pages) ------------
Total free pages: 31905
  Order  0 (size     1): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

**释放阶段：**

* 释放p0(8页）：order3链表增加一个块

```sql
------------ After freeing the first block (5 pages) ------------
Total free pages: 31913
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

* 释放p1(8页）

```sql
------------ After freeing the second block (7 pages) ------------
Total free pages: 31921
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 2 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

没有伙伴，order3加一块

* &#x20;释放 p2 (8页)：

```sql
------------ After freeing the third block (5 pages) ------------
Total free pages: 31929
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

系统检测到它的伙伴（`p1`分裂出的另一半）是空闲的，触发合并，形成一个 `Order 4` 的块。这个新块又和它的伙伴（`p0`分裂出的）合并... 最终，所有被借用的内存都完美地回到了初始状态。

### 测试场景2：边界测试（最大&最小分配）

#### 1. 测试函数代码

通过 `check_edge_cases` 函数，分配 1 页（最小单元），释放 1 页；然后分配当前最大的可用块，再释放。通过这个测试场景可以检测系统处理最大和最小分配请求的能力，检测最深的分裂和最高阶的合并。

```c++
static void check_edge_cases(void) {
    cprintf("\n[Test 2: Edge Case Alloc & Free]\n");
    struct Page *p_min = alloc_pages(1); assert(p_min != NULL);
    show_buddy_info("After allocating 1 page (max splitting)");
    free_pages(p_min, 1); show_buddy_info("After freeing 1 page (max merging)");
    size_t max_order = 0;
    for(int i = MAX_ORDER - 1; i >= 0; i--) { if(!list_empty(&free_list_at(i))) { max_order = i; break; } }
    size_t max_size = 1 << max_order;
    struct Page *p_max = alloc_pages(max_size); assert(p_max != NULL);
    show_buddy_info("After allocating the largest available block");
    free_pages(p_max, max_size); show_buddy_info("After freeing the largest block");
}
```

#### 2. 结果分析

**分配1页：**

```sql
----------- After allocating 1 page (max splitting) ------------
Total free pages: 31928
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

系统正确地从初始状态中拿走了唯一的 `Order 0` 块，无需进行复杂的分裂。

**释放1页：**

```sql
------------ After freeing 1 page (max merging) ------------
Total free pages: 31929
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

释放的1页块被归还。因为它的伙伴不是一个空闲的 `Order 0` 块，所以没有发生合并，系统**正确地恢复**到了初始状态。

**分配&释放最大块**

```sql
------------ After allocating the largest available block ------------
Total free pages: 15545
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
----------------------------------------
------------ After freeing the largest block ------------
Total free pages: 31929
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
----------------------------------------
```

系统正确地分配了最大的 `Order 14` 块，然后又成功释放并使其回到空闲链表，内存状态恢复。

### 测试场景3：复杂分配&乱序释放

#### 1. 测试函数代码

通过 `check_complex_merge` 函数，分配 4 个不同大小的块 (4, 15, 4, 15 页)，然后以 `b1, b3, b0, b2` 的乱序进行释放。通过乱序释放，检验系统能否在正确的时机（即伙伴双方都变为空闲时）才触发合并。

#### 2. 结果分析

首先释放b1（16页），`b1` 被放入 `Order 4` 链表。其伙伴 `b3` 仍被占用，不合并。

```sql
--> Freeing b1 (15 pages)...
------------ State after freeing b1 ------------
Total free pages: 31905
  Order  0 (size     1): 1 blocks
  Order  4 (size    16): 2 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

接下来释放b3（也是16页），`b3` 被释放。系统立即检测到其伙伴 `b1` 已在空闲链表中，**成功触发合并**，形成一个 `Order 5` 的块。

```sql
--> Freeing b3 (15 pages)...
------------ State after freeing b3 (should merge with b1) ------------
Total free pages: 31921
  Order  0 (size     1): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
```

接下来就是b0和b2，同理

`b0` 被放入 `Order 2` 链表。其伙伴 `b2` 仍被占用，不合并。

`b2` 被释放，立刻与 `b0` 合并为 `Order 3` 块，并继续触发连锁合并。

最终，内存同样完美地恢复到了初始状态。

```sql
-> Freeing b0 (4 pages)...
------------ State after freeing b0 ------------
Total free pages: 31925
  Order  0 (size     1): 1 blocks
  Order  2 (size     4): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
----------------------------------------
--> Freeing b2 (4 pages)...
------------ State after freeing b2 (should merge with b0, and trigger further merges) ------------
Total free pages: 31929
  Order  0 (size     1): 1 blocks
  Order  3 (size     8): 1 blocks
  Order  4 (size    16): 1 blocks
  Order  5 (size    32): 1 blocks
  Order  7 (size   128): 1 blocks
  Order 10 (size  1024): 1 blocks
  Order 11 (size  2048): 1 blocks
  Order 12 (size  4096): 1 blocks
  Order 13 (size  8192): 1 blocks
  Order 14 (size 16384): 1 blocks
----------------------------------------
>>> Test 3 PASSED: Memory fully recovered.
```

# Challenge2：任意大小的内存单元slub分配算法

## 一、算法设计

### 1.设计原理

SLUB（Slab Utilization By-pass）是 Linux 内核中的一种内存分配器，专门用于高效地管理内核中的小&#x20;

对象。它是 SLAB 分配器的改进版本，旨在提高性能、简化实现并减少内存碎片。SLUB 是现代 Linux 内&#x20;

核中默认的内存分配器，广泛用于分配和回收内核数据结构，如进程描述符、文件描述符等。

**slub 核心思想 ：**&#x901A;过预分配固定大小的内存块（称为 slabs）来管理和分配内存。每个 slab 包含多个相同大小的对象， 这些对象可以被快速分配和释放。

**slub算法实现 :&#x20;**&#x4E24;层架构的高效内存单元分配，第一层是基于页大小的内存分配，第二 层是在第一层基础上实现基于任意大小的内存分配。 因此，我们保留页级别的分配策略，比如default（First-Fit）或Best-Fit算法，以当作第一层的分配，用户要求大内存分配的时候它们负责。而小内存需求由第二层来管理，从一个底层页分配器（如代码中的 Best-Fit）申请一个或多个连续的物理页，形成一个 Slab（代码中为1页，4KB）。然后在这个 Slab 上划分出多个等大的对象。

### 2.数据结构设计

#### (1) slab结构体：内存管理的基本单元

```c++
typedef struct slab_s {
    list_entry_t list;       // 链接自身的 (到 cache_t->slabs 列表)
    size_t free_cnt;         // Slab 中空闲对象数量
    void *objs;              // 对象寻址指针 (实际对象数据的起始地址)
    unsigned char *bitmap;   // 位图 (标记对象的使用与否)
    cache_t *cache;          // 指向所属的 kmem_cache
} slab_t;
```

#### (2) cache结构体：同类型对象的内存池

```c++
typedef struct cache_s {
    list_entry_t cache_link; // 链接所有 kmem_cache (全局列表)
    const char *name;
    size_t obj_size;         // 每个对象的大小
    size_t objs_num;         // 一个 Slab 中可容纳的对象数
    
    list_entry_t slabs;      // 链接 Slab (所有部分/完全空闲的 Slab 列表)
    
    // 统计信息
    size_t slabs_total;      // 总 Slab 数量
    size_t objects_free;     // 当前空闲对象总数 (用于 nr_free_pages/check)
} cache_t;
```

### 3.核心函数

#### (1) cache 初始化

```c
static void cache_init(void){
    
    cache_n=3;
    size_t sizes[3]={32,64,128};
    for(int i=0;i<cache_n;i++){
        caches[i].obj_size=sizes[i];
        caches[i].objs_num=calculate_objs_num(sizes[i]);
        list_init(&caches[i].slabs);
    }
}
```

预定义 3 个固定大小的缓存池：32B、64B、128B，为每个 cache 初始化对象大小、对象数目和 slab 链表，这为后续的小对象分配提供基础结构。

#### (2) slub初始化

```c
static void
slub_init(void) {
    base_pmm->init();       // 初始化底层 PMM
    cache_init();           // 初始化第二层：SLUB 缓存
}
```

调用底层物理页分配器 `base_pmm->init()`，然后初始化 SLUB 的多级缓存结构，使得整个内存管理系统分为 **页级（PMM）** 和 **对象级（SLUB）** 两层。

#### (3) 调用底层 PMM

初始化memmap、申请和释放页、查询当前空闲页数均调用底层PMM的相应函数。

```c
static void
slub_init_memmap(struct Page *base,size_t n){
    base_pmm->init_memmap(base,n); // 调用底层 PMM 的 init_memmap
}
// SLUB PMM 的页分配封装函数
static struct Page *
slub_alloc_pages(size_t n) {
    return base_pmm->alloc_pages(n);
}
static void
slub_free_pages(struct Page *base, size_t n) {
    base_pmm->free_pages(base, n);
}
static size_t
slub_nr_free_pages(void) {
    return base_pmm->nr_free_pages(); // 使用 base_pmm 的空闲页数
}
```

#### (4) Slab 创建与管理

```c
static slab_t* create_slab(size_t obj_size,size_t objs_num){
    struct Page* page=base_pmm->alloc_pages(1);
    if(!page)return NULL;
    void* kva=KADDR(page2pa(page));
    slab_t *slab=(slab_t*)kva;
    slab->free_cnt=objs_num;
    slab->objs=(void*)slab+sizeof(slab_t);//指向对象存储区域
    slab->bitmap=(unsigned char*)((void*)slab->objs+obj_size*objs_num);//指向位图区域
    memset(slab->bitmap,0,(objs_num+7)/8);
    list_init(&slab->list);
    return slab;
}
```

首先分配一个物理页，并在页首放置 `slab_t` 结构，接着是对象存储区，再计算位图地址，最后初始化空闲计数和链表节点，返回已初始化的 `slab_t`。

#### (5) 对象分配函数

```c
static void* slub_alloc_obj(size_t size){
    if(size<=0) return NULL;
    // 1. 查找合适的 cache
    cache_t *cache=NULL;
    for(int i=0;i<cache_n;i++){
        if(caches[i].obj_size>=size){
            cache =&caches[i];
            break;
        }
    }
    if(cache==NULL) return NULL;
    // 2. 遍历 slab，寻找空闲对象
    list_entry_t *le=&cache->slabs;
    while ((le = list_next(le)) != &cache->slabs) {
        slab_t *slab = container_of(le, slab_t, list);
        if (slab->free_cnt > 0) {
            for (size_t i = 0; i < cache->objs_num; i++) {
                size_t byte = i / 8;
                size_t bit = i % 8;
                if (!(slab->bitmap[byte] & (1 << bit))) {
                    slab->bitmap[byte] |= (1 << bit); // 标记为已分配
                    slab->free_cnt--;
                    return (void*)slab->objs + i * cache->obj_size;//返回地址指针
                }
            }
        }
    }
    // 3. 若无空闲 slab，则创建新 slab
    slab_t *new_slab=create_slab(cache->obj_size,cache->objs_num);
    if(!new_slab) return NULL;
    list_add(&cache->slabs,&new_slab->list);
    // 分配第一个对象
    new_slab->bitmap[0] |= 1;
    new_slab->free_cnt--;
    return new_slab->objs;
}
```

对象分配流程如下：

1. 根据请求大小，找到最合适的缓存池；

2. 在已有 slab 中查找空闲对象：通过位图检测空闲位，然后将该位置标为已使用，并返回对象地址；

3. 若没有可用 slab，则创建新 slab，并为新 slab 分配第一个对象并返回。

#### (6) 对象释放函数

```c++
static void
slub_free_obj(void* obj){
    for (size_t i = 0; i < cache_n; i++) {
        cache_t *cache = &caches[i];
        list_entry_t *le = &cache->slabs;
        while ((le = list_next(le)) != &cache->slabs) {
            slab_t *slab = container_of(le, slab_t, list);
            if (obj >= slab->objs && obj < (slab->objs + cache->obj_size * cache->objs_num)) {
                size_t offset = (char*)obj - (char*)slab->objs;
                size_t index = offset / cache->obj_size;
                size_t byte = index / 8;
                size_t bit = index % 8;
                if (slab->bitmap[byte] & (1 << bit)) {
                    slab->bitmap[byte] &= ~(1 << bit); // 标记为未分配
                    slab->free_cnt++;
                    memset(obj, 0, cache->obj_size);//释放清零
                    // 如果整个slab都是空闲的，可以将其释放
                    if (slab->free_cnt == cache->objs_num) {
                        list_del(&slab->list);
                        base_pmm->free_pages(pa2page(PADDR(slab)), 1);
                    }
                }
                return;
            }
        }
    }
}
```

对象释放流程如下：

1. 遍历所有 cache，并进一步遍历所有 slab。

2. 根据对象地址范围判断该对象属于哪个 slab。

3. 清除位图标志，标记为空闲，然后更新空闲计数。

4. 若该 slab 全部空闲，则将该页归还给底层 PMM。

## 二、测试用例&结果分析

`slub_check` 函数是为确保我们实现的 SLUB 内存分配器逻辑正确性而设计的一系列单元测试和压力测试。我们通过断言（`assert`）来验证分配器在各种场景下的行为是否符合预期。

### 1.初始化和配置检查

```c++
cprintf("The slab struct size is %d\n",sizeof(slab_t));
// ...
size_t nums[3]={126,63,31};
for(int i=0;i<cache_n;i++){
    assert(caches[i].objs_num==nums[i]);
}
size_t nr_1=slub_nr_free_pages(); // 记录初始空闲页数
```

这一部分的代码是为了验证 SLUB 缓存的初始化配置是否正确。

验证 `cache_init` 和 `calculate_objs_num` 函数计算出的每个 Slab（页）中可容纳的对象数量是否正确。

* 32 字节对象：断言每个 Slab 容纳 **126** 个对象。

* 64 字节对象：断言每个 Slab 容纳 **63** 个对象。

* 128 字节对象：断言每个 Slab 容纳 **31** 个对象。

这个函数确保每个 Slab 中能容纳的对象数量计算正确。



结果展示：

```c
Starting SLUB allocator tests...

The slab struct size is 48
```

### 2.边界检查&#x20;

```plain&#x20;text
{
    void* obj=slub_alloc_obj(0);
    assert(obj==NULL);
    obj=slub_alloc_obj(256);
    assert(obj==NULL);
    cprintf("Boundary check passed. \n");
}
```

这段代码目的是验证对无效或超出 SLUB 缓存范围的请求处理是否正确。我们分别测试请求分配0字节以及256字节（我们的`caches` 最大只支持 128 字节）。这两个请求正常情况下应该都不通过（即obj==NULL），当测试通过时，输出`Boundary check passed.`

我们的测试结果如下：

```plain&#x20;text
Boundary check passed. 
```

### 3.单个分配/释放功能检查

这部分的代码目的是验证分配、写入和**内存清零**功能。

```c
//——————————分配释放功能检查
    {
        void* obj1=slub_alloc_obj(32);
        assert(obj1!=NULL);
        cprintf("Allocated 32-byte object at %p\n", obj1);
        memset(obj1,0x66,32);
        for(int i=0;i<32;i++){
            assert(((unsigned char*)obj1)[i]==0x66);
        }
        cprintf("Memory alloc verification passed. \n");
        slub_free_obj(obj1);

        void* obj2=slub_alloc_obj(32);
        cprintf("Allocated 32-byte object at %p\n", obj2);
        for(int i = 0; i < 32; i++) {
            assert(((unsigned char*)obj2)[i] == 0x00);
        }
        slub_free_obj(obj2);
        cprintf("Memory free verification passed. \n");
    }
```

* 第一次分配 `obj1`，写入数据。释放 `obj1` 后，再次分配 `obj2`（通常会重用 `obj1` 的地址）。此时，**断言** `obj2` 的所有字节都为 `0x00`。

* **代码对应：** 这直接验证了 `slub_free_obj` 中的这行代码：`memset(obj, 0, cache->obj_size);`。

结果如下：

```c
Allocated 32-byte object at 0xffffffffc0348030//这是第一次分配 32B 对象。SLUB 必须向底层 PMM 申请 1 页（0xc0348000 对应的一页），并在其内部的偏移量 +0x30 处返回第一个对象地址。
Memory alloc verification passed. //释放 obj1，位图被清 0，但 Slab 尚未被回收（因为测试尚未结束）。
Allocated 32-byte object at 0xffffffffc0348030//obj2 的地址与 obj1 相同，说明 SLUB 成功重用了刚刚释放的空闲对象。
Memory free verification passed. //验证了 obj1 释放时，其内存被 memset 清零了。
```

### 4.多个分配/释放功能检查

这段代码目的是验证在同一个 Slab 内部进行多次分配和释放时，位图和地址计算的正确性。

```c
 //——————————多个分配释放功能检查
    {
        const int NUM_TEST_OBJS = 10;
        void* test_objs[NUM_TEST_OBJS];
        cprintf("Allocating %d objects of size 64 bytes.\n", NUM_TEST_OBJS);
        for(int i = 0; i < NUM_TEST_OBJS; i++) {
            test_objs[i] = slub_alloc_obj(64);
            assert(test_objs[i] != NULL);
            // 赋值
            memset(test_objs[i], i, 64);
        }
    
        for(int i = 0; i < NUM_TEST_OBJS; i++) {
            for(int j = 0; j < 64; j++) {
                assert(((unsigned char*)test_objs[i])[j] == (unsigned char)i);
            }
        }
        cprintf("Memory verification for 64-byte objects passed.\n");
        // 释放对象
        for(int i = 0; i < NUM_TEST_OBJS; i++) {
            slub_free_obj(test_objs[i]);
            cprintf("Freed 64-byte object at %p\n", test_objs[i]);
            // 验证内存是否被清零
            for(int j = 0; j < 64; j++) {
                assert(((unsigned char*)test_objs[i])[j] == 0x00);
            }
        }
        cprintf("Memory free verification for 64-byte objects passed.\n");
    }
```

为每个对象写入一个基于其索引的唯一值（例如，第 i个对象写入 i）。如果分配逻辑有误（例如地址重叠），验证步骤就会失败。同时，确认批量释放后，每个对象的内存都被清零。

测试结果如下：

```python
Allocating 10 objects of size 64 bytes.
Memory verification for 64-byte objects passed.
Freed 64-byte object at 0xffffffffc0348030
Freed 64-byte object at 0xffffffffc0348070
Freed 64-byte object at 0xffffffffc03480b0
Freed 64-byte object at 0xffffffffc03480f0
Freed 64-byte object at 0xffffffffc0348130
Freed 64-byte object at 0xffffffffc0348170
Freed 64-byte object at 0xffffffffc03481b0
Freed 64-byte object at 0xffffffffc03481f0
Freed 64-byte object at 0xffffffffc0348230
Freed 64-byte object at 0xffffffffc0348270
Memory free verification for 64-byte objects passed.
```

接下来我对结果进行一下解释：

关于`Allocating 10 objects of size 64 bytes.`
`Memory verification for 64-byte objects passed.`

这是程序第一次分配 64 字节的对象。它需要使用 64B 缓存 (caches\[1])。

* `slub_alloc_obj(64)` 会查找 64B 缓存的 `slabs` 列表，发现为空。

* 因此，它调用 `create_slab` 向底层 PMM 申请一个新的 4KB 物理页

* 新 Slab 的对象起始地址是 `slab` 的 KVA 加上 `sizeof(slab_t)` (48 字节)：

关于地址的分配：

`Freed 64-byte object at 0xffffffffc0348030`
`Freed 64-byte object at 0xffffffffc0348070`
`Freed 64-byte object at 0xffffffffc03480b0`
`Freed 64-byte object at 0xffffffffc03480f0`
`Freed 64-byte object at 0xffffffffc0348130`
`Freed 64-byte object at 0xffffffffc0348170`
`Freed 64-byte object at 0xffffffffc03481b0`
`Freed 64-byte object at 0xffffffffc03481f0`
`Freed 64-byte object at 0xffffffffc0348230`
`Freed 64-byte object at 0xffffffffc0348270`

**10 个对象的地址:** 64 字节对象是紧密排列的，这些地址之间恰好相差 **64 字节**，完美对应了 64 字节的对象大小。这证明了 `slub_free_obj` 函数通过指针计算对象索引和操作位图的逻辑是正确的。

最后在释放完第 10 个对象后，Slab 变成了完全空闲（`slab->free_cnt == cache->objs_num`），`Memory free verification for 64-byte objects passed.` 证明了释放后，每个对象的 64 字节内存都被正确地清零了。

### 5.大量分配/释放检查

这部分的代码是为了验证 SLUB 的**容量扩展**和**精确的页消耗。**

```java
{
    // ... nr_1 是初始页数
    // 10000个25字节对象 (使用32B Cache，126 objs/slab)
    for(int i=1;i<=10000;i++){
        objs_bulk[i-1]=slub_alloc_obj(25);
        assert(slub_nr_free_pages()==nr_1-(i+125)/126); 
    }
    nr_2=slub_nr_free_pages(); // 记录当前页数

    // 10000个62字节对象 (使用64B Cache，63 objs/slab)
    for(int i=1;i<=10000;i++){
        objs_bulk[i+9999]=slub_alloc_obj(62);
        assert(slub_nr_free_pages()==nr_2-(i+62)/63); 
    }
    // ... 128B 对象测试类似

    // ... 失败分配检查：29999个对象后，分配超大对象
    assert(objs_bulk[i+29999]==NULL); 

    // ... 释放所有 30000 个对象
    assert(slub_nr_free_pages()==nr_1); // 最终断言
}
```

其中，`assert(slub_nr_free_pages()==nr_1-(i+125)/126);`是关键断言。

* nr\_1是初始页数。

* `(i+125)/126`是计算i个32B 对象需要多少个 Slab（页数）。例如，i=126时，我们需要`(126+125)/126=251/126=1`个页；i=127时，我们需要`(127+125)/126=252/126=2`个页。

* 断言保证了分配器**仅在当前 Slab 满时**才向底层 PMM (`best_fit_pmm`) 请求新页。

在最终的断言之中，我们确保释放所有对象后，`assert(slub_nr_free_pages()==nr_1);` 所有被分配和使用的页都被正确地释放回了底层 PMM，没有发生内存泄漏。



结果如下：

```c
Bulk allocation release check start.
Bulk allocation release check passed. (nr_free: 31928)
```

* 代码中的 3 次动态断言 (`assert(slub_nr_free_pages()==nr_X-(i+Y)/Z);`) 在输出中没有报错，说明 SLUB 严格遵守了其 Slab 扩展策略——**仅在当前 Slab 满了之后**才会调用 `base_pmm->alloc_pages(1)`。

* 释放所有 30000 个对象后，空闲页数**精确地**回到了初始值 `nr_1` (31928)。这证明了所有为满足批量分配而创建的 Slab 页都被正确地回收，**无内存泄漏。**

### 6.复杂流程检查 (Slab 回收时机验证)

&#x20;这是最精细的测试，验证 `slub_free_obj` 中的**Slab 回收条件**是否精确。

```java
{
    // ... 分配 obj1(32B), obj2(64B), obj3(128B) -> nr_1 - 3 页被占用
    
    // obj4(32B) 重用 obj1 所在的 Slab -> 页数不变
    assert(slub_nr_free_pages()==nr_1-3); 
    
    // obj6(128B) 强制创建第二个 128B Slab -> 页数减少
    assert(slub_nr_free_pages()==nr_1-4);

    // ... 释放 obj[1] 到 obj[29] (128B Slab 1 仍被 obj3, obj5 占用) -> 页数不变
    assert(slub_nr_free_pages()==nr_1-4);

    // slub_free_obj(obj2); (64B Slab 1 仅有 obj2，现在完全空闲) -> 回收 1 页
    assert(slub_nr_free_pages()==nr_1-3);

    // slub_free_obj(obj4); (32B Slab 1 仅有 obj4，现在完全空闲) -> 回收 1 页
    assert(slub_nr_free_pages()==nr_1-2);
    
    // ... 最终 slub_free_obj(obj6) (最后一个 Slab) -> 回收 1 页
    assert(slub_nr_free_pages()==nr_1);
}
```

我们的测试逻辑为：只有当一个 Slab 中的 `slab->free_cnt` 等于 `cache->objs_num` 时（即 Slab 完全空闲），它才会被 `list_del` 并通过 `base_pmm->free_pages(pa2page(PADDR(slab)), 1);` 回收。

我们的步骤为：

故意分配对象，使得 32B Slab、64B Slab 和 128B Slab 都处于**非满但未空闲**的状态。然后，以特定的顺序释放对象，精确地验证只有当**Slab 中的最后一个对象被释放时**，空闲页数才会增加 1。



测试结果：

```java
Mixed check start.
Allocated 32-byte object at 0xffffffffc0348030
Allocated 64-byte object at 0xffffffffc0349030
Allocated 128-byte object at 0xffffffffc034a030
Allocated second 32-byte object at 0xffffffffc0348050
Allocated 31th 128-byte object at 0xffffffffc034af30
Allocated 32th(new slam) 128-byte object at 0xffffffffc034b030
Mixed check passed.
```

我们来解释一下这个输出：

**代码的第五行进行了Slab 重用：** 地址在 `0xc0348000` 页内，页数不变 (`nr_1 - 3`)。

**代码的第六行进行了Slab 填满：** 这是 128B Slab 的第 31 个对象，页数不变 (`nr_1 - 3`)。

**代码的第七行重新分配了一页：Slab 4 (128B) ：`0xc034b000`。页数减 1 (`nr_1 - 4`)。**

最后我们成功通过了混合测试！

# Challenge3：硬件的可用物理内存范围的获取方法

1. **解析引导程序(Bootloader)信息**

* OS 读取引导程序（如 OpenSBI 或 UEFI/BIOS）在启动时扫描好的内存信息

* 在我们的 RISC-V 实验中，这就是指解析 OpenSBI 在 `a1` 寄存器中传入的**设备树 (DTB)** 。DTB 的 `/memory` 节点会明确列出所有可用 RAM 的**起始地址**和**大小**。

* 在 x86 上，这对应的是读取 **E820 映射表**。

- **手动内存探测（“RAM Banging”）（可能存在风险）**

* 在没有固件信息时，OS 只能“手动”探测。

* 它会从一个地址开始，逐页（4KB）地**写入**一个特定值（如 `0x55AA55AA`），然后**读回**看是否一致 ()。如果读写都成功，就标记为可用 RAM。

* **风险：存在风险**，因为它可能会不小心**写入 MMIO（内存映射 I/O）区域**，导致硬件设备（如磁盘）执行意外操作，造成系统崩溃。

- **探测总线与 CPU 的寻址宽度（优化方法）**

该方法的核心目的**不是**获取物理 RAM 的具体*范围*或探测 MMIO“空洞”，而是确定硬件（CPU 和总线）在理论上能支持的**最大物理地址空间** ()。

它主要作为**方法二（手动内存探测）的一个关键优化：为危险的“RAM Banging”探测提供一个明确的上限**，避免 OS 盲目地去探测整个 64 位（16 EB）地址空间。

具体实现技术包括：

* **主动探测总线（如 PCIe BAR 反射探测）：** 操作系统在初始化时，可向 PCI/PCIe 设备的 BAR（基础地址寄存器）写入一个全 1 的值（例如 `0xFFFFFFFF`）()。当立即读回时，总线硬件会自动将其无法寻址的高位清零 ()。通过分析这个读回的值，OS 即可推断出总线支持的最大物理地址*宽度* ()。

* **查询 CPU 自身声明（如 MSR 寄存器）：** OS 也可以直接“询问”CPU。例如，在 x86 架构上，OS 可通过 `CPUID` 指令或读取特定的 **MSR (Model-Specific Register)** ()，来直接获取 CPU 声明支持的“最大物理地址位数”（Physical Address Width）()。

**总结：** 这种方法通过硬件探测和查询，让 OS 得知（例如）整套系统最多只支持 36 位地址（64GB）。因此，方法二的手动探测就不需要盲目进行，其探测上限可以被安全地限制在 64GB，极大地缩小了探测范围并提高了启动效率。

